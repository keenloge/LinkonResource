//
//  InfoButton.h
//  LinKon
//
//  Created by Keen on 2017/6/13.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import "BaseButton.h"

@interface InfoButton : BaseButton

@end
