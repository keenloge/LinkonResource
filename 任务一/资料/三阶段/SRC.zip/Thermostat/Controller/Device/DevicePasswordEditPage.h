//
//  DevicePasswordEditPage.h
//  Thermostat
//
//  Created by Keen on 2017/6/16.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import "DeviceInputPage.h"

@interface DevicePasswordEditPage : DeviceInputPage

- (instancetype)initWithDevice:(long long)sn;

@end
