//
//  TaskListPage.h
//  Thermostat
//
//  Created by Keen on 2017/6/4.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import "BaseListViewPage.h"

@interface TaskListPage : BaseListViewPage

- (instancetype)initWithDevice:(long long)sn;

@end
