//
//  ViewDeckAdditions.h
//  Thermostat
//
//  Created by Keen on 2017/6/17.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import <ViewDeck.h>

@interface IIViewDeckController (StatusBarStyle)

/*
 修改颜色
 IIViewDeckController.mm
 decorationView.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.75];

 修改位置偏移
 IIViewDeckLayoutSupport.m
 CGFloat xOffset = (openSide == IIViewDeckSideLeft ? maxSize.width * 0.1 : -maxSize.width * 0.1);
 */

@end
