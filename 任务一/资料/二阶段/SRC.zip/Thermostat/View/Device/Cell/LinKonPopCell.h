//
//  LinKonPopCell.h
//  Thermostat
//
//  Created by Keen on 2017/6/17.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import "BaseCell.h"

@interface LinKonPopCell : BaseCell

@property (nonatomic, strong) UIImage *iconImage;
@property (nonatomic, strong) NSString *nameString;

@end
