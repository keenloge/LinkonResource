//
//  SettingArrowCell.h
//  Thermostat
//
//  Created by Keen on 2017/6/2.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import "BaseIconCell.h"

@interface SettingArrowCell : BaseIconCell

@end
