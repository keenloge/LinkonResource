//
//  MenuControlView.h
//  Thermostat
//
//  Created by Keen on 2017/6/1.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import "BaseView.h"

@interface MenuControlView : BaseView

@property (nonatomic, strong) NSString *sn;

@end
