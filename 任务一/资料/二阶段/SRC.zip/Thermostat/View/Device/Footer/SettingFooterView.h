//
//  SettingFooterView.h
//  Thermostat
//
//  Created by Keen on 2017/6/2.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingFooterView : UITableViewHeaderFooterView

@property (nonatomic, strong) NSString *introduce;

@end
