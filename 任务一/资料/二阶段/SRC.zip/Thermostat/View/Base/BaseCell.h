//
//  BaseCell.h
//  LinKon
//
//  Created by Keen on 2017/6/13.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseCell : UITableViewCell

- (void)baseInitialiseSubViews;

@end
