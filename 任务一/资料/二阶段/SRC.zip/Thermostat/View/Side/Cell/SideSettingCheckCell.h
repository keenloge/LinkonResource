//
//  SideSettingCheckCell.h
//  Thermostat
//
//  Created by Keen on 2017/6/17.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import "SideSettingCell.h"

@interface SideSettingCheckCell : SideSettingCell

@end
