//
//  SideSettingCheckCell.m
//  Thermostat
//
//  Created by Keen on 2017/6/17.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import "SideSettingCheckCell.h"

@implementation SideSettingCheckCell

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)baseInitialiseSubViews {
    [super baseInitialiseSubViews];
    
    self.tintColor = HB_COLOR_BASE_MAIN;
}

@end
