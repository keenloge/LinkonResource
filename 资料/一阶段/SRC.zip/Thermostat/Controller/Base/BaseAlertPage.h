//
//  BaseAlertPage.h
//  Thermostat
//
//  Created by Keen on 2017/5/31.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseAlertPage : UIViewController

- (void)baseInitialiseSubViews;
- (void)baseBack;

@end
