//
//  DeviceAddPage.h
//  Thermostat
//
//  Created by Keen on 2017/6/1.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import "BaseViewPage.h"

@interface DeviceAddPage : BaseViewPage

@end
