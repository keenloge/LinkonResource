//
//  ControlMenuButton.h
//  Thermostat
//
//  Created by Keen on 2017/6/1.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import "BaseButton.h"

@interface ControlMenuButton : BaseButton

@end
