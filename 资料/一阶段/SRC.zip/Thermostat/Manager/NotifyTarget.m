//
//  NotifyTarget.m
//  Thermostat
//
//  Created by Keen on 2017/6/1.
//  Copyright © 2017年 GalaxyWind. All rights reserved.
//

#import "NotifyTarget.h"

@interface NotifyTarget ()


@end

@implementation NotifyTarget

//- (NSMutableArray *)keyArray {
//    if (!_keyArray) {
//        _keyArray = [NSMutableArray array];
//    }
//    return _keyArray;
//}

- (NSMutableDictionary *)blockDictionary {
    if (!_blockDictionary) {
        _blockDictionary = [NSMutableDictionary dictionary];
    }
    return _blockDictionary;
}

@end
